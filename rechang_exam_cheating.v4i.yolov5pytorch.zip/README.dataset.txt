# rechang_exam_cheating > 2024-01-29 9:50pm
https://universe.roboflow.com/examcheating/rechang_exam_cheating

Provided by a Roboflow user
License: CC BY 4.0

